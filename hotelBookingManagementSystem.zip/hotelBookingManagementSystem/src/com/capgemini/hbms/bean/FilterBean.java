package com.capgemini.hbms.bean;

public class FilterBean {
	
	private int hotelId;
	private int roomId;
	public FilterBean() {
		super();
	}
	public FilterBean(int hotelId, int roomId) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	
	
	

}
