package com.capgemini.hbms.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.dao.HotelDAOImpl;
import com.capgemini.hbms.dao.IHotelDAO;


public class HotelDAOImplTest {
	IHotelDAO hotelDAO = null;
	
	/*
	patientDAO= new PatientDAO();
	PatientBean patientBean= new PatientBean("test",20,"7894563211","suffering from cold");
	patientDAO.addPatientDetails(patientBean);
	assertEquals(2, patientBean.getPatientId());
	assertEquals("test", patientBean.getPatientName());
	assertEquals(20, patientBean.getAge());
	assertEquals("7894563211", patientBean.getPhone());
	assertEquals("suffering from cold", patientBean.getDescription());
*/
	@Test
	public void testAddHotel() {
		hotelDAO = new HotelDAOImpl();
		HotelBean hotelBean=new HotelBean();
		
	}

	@Test
	public void testDeleteHotelValidate() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testModifyHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddRoom() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteRoomValidate() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteRoom() {
		fail("Not yet implemented");
	}

	@Test
	public void testModifyRoom() {
		fail("Not yet implemented");
	}

	@Test
	public void testRegisterUser() {
		fail("Not yet implemented");
	}

	@Test
	public void testLoginValidation() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewHotelCity() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewRoom() {
		fail("Not yet implemented");
	}

	@Test
	public void testFilterHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testBookHotel() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewBookStatus() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewAllHotels() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewSpecificHotelBooking() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewSpecificHotelGuestList() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewSpecificDateBooking() {
		fail("Not yet implemented");
	}

}
